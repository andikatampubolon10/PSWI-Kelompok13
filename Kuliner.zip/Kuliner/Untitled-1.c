#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_NAMA 50
#define MAX_RUTE 50
#define MAX_WAKTU 20

// Struktur untuk menyimpan data mobil
typedef struct {
    char jenis[50];
    int harga[4]; // Tarif per rute
} Mobil;
int i;
// Struktur untuk menyimpan data transaksi
typedef struct {
    char nama[MAX_NAMA];
    char jenisMobil[50];
    char rute[MAX_RUTE];
    int harga;
    char waktuPemakaian[MAX_WAKTU];
    char waktuPengembalian[MAX_WAKTU];
} Transaksi;

// Fungsi untuk menampilkan pilihan dan memproses input pengguna
void menu(char *nama) {
    printf("\n==== Selamat datang, %s ====\n", nama);
    printf("1. Pinjam Mobil\n");
    printf("2. Lihat Ketersediaan Mobil\n");
    printf("3. Cek Mobil Tersedia (per tanggal)\n");
    printf("4. Lihat Riwayat Transaksi\n");
    printf("0. Keluar\n");
}

// Fungsi untuk menampilkan jenis mobil yang dapat dipinjam
void tampilkanJenisMobil(Mobil *mobilList, int mobilCount) {
    printf("\nJenis Mobil yang Tersedia:\n");
    for (i = 0; i < mobilCount; i++) {
        printf("%d. %s\n", i + 1, mobilList[i].jenis);
    }
}

// Fungsi untuk menampilkan rute yang tersedia dari file rute.txt
void tampilkanRute() {
    printf("\nRute yang Tersedia:\n");

    FILE *fileRute = fopen("rute.txt", "r");
    if (fileRute == NULL) {
        perror("Error opening file rute.txt");
        return;
    }

    char line[MAX_RUTE];
    while (fgets(line, sizeof(line), fileRute)) {
        line[strcspn(line, "\n")] = '\0'; // Menghapus newline dari setiap baris
        printf("%s\n", line);
    }

    fclose(fileRute);
}

// Fungsi untuk membaca data mobil dari file mobil.txt
int bacaDataMobil(Mobil **mobilList) {
    FILE *fileMobil = fopen("mobil.txt", "r");
    if (fileMobil == NULL) {
        perror("Error opening file mobil.txt");
        return 0; // Gagal membaca file
    }

    int mobilCount;
    fscanf(fileMobil, "%d", &mobilCount);

    *mobilList = (Mobil *)malloc(mobilCount * sizeof(Mobil));

    for (i = 0; i < mobilCount; i++) {
        fscanf(fileMobil, "%s %d %d %d %d", (*mobilList)[i].jenis,
               &(*mobilList)[i].harga[0], &(*mobilList)[i].harga[1],
               &(*mobilList)[i].harga[2], &(*mobilList)[i].harga[3]);
    }

    fclose(fileMobil);
    return mobilCount; // Mengembalikan jumlah data mobil yang berhasil dibaca
}

// Fungsi untuk mencari indeks mobil berdasarkan jenis mobil
int cariIndeksMobil(Mobil *mobilList, int mobilCount, const char *jenisMobil) {
    for (i = 0; i < mobilCount; i++) {
        if (strcmp(mobilList[i].jenis, jenisMobil) == 0) {
            return i;
        }
    }
    return -1; // Mengembalikan -1 jika jenis mobil tidak ditemukan
}

// Fungsi untuk mencatat data transaksi ke dalam file
void catatTransaksi(Transaksi *transaksi, int jumlahTransaksi) {
    FILE *file = fopen("transaksi.txt", "a");
    if (file == NULL) {
        perror("Error opening file");
        return;
    }

    for (i = 0; i < jumlahTransaksi; i++) {
        fprintf(file, " %s | %s | %s | %d | %s | %s |\n",
                transaksi[i].nama, transaksi[i].jenisMobil, transaksi[i].rute,
                transaksi[i].harga, transaksi[i].waktuPemakaian, transaksi[i].waktuPengembalian);
    }

    fclose(file);
}

int main() {
    // Inisialisasi data mobil
    Mobil *mobilList;
    int mobilCount = bacaDataMobil(&mobilList);

    // Seed untuk random number generator
    srand(time(NULL));

    char nama[MAX_NAMA];
    int pilihan;

    printf("Masukkan Nama Anda: ");
    fgets(nama, sizeof(nama), stdin);
    nama[strcspn(nama, "\n")] = '\0'; // Menghapus newline dari input

    // Inisialisasi array untuk menyimpan data transaksi
    Transaksi *transaksi = NULL;
    int jumlahTransaksi = 0;

    do {
        menu(nama);
        printf("Pilihan Anda: ");
        scanf("%d", &pilihan);

        switch (pilihan) {
            case 1: // Pinjam Mobil
                tampilkanJenisMobil(mobilList, mobilCount);

                char jenisMobil[50];
                printf("Pilih mobil yang ingin dipinjam (nama): ");
                getchar(); // Membersihkan newline dari input sebelumnya
                fgets(jenisMobil, sizeof(jenisMobil), stdin);
                jenisMobil[strcspn(jenisMobil, "\n")] = '\0'; // Menghapus newline dari input

                int mobilIndex = cariIndeksMobil(mobilList, mobilCount, jenisMobil);

                if (mobilIndex != -1) {
                    char rute[MAX_RUTE];
                    printf("Pilih rute (nama): ");
                    getchar(); // Membersihkan newline dari input sebelumnya
                    fgets(rute, sizeof(rute), stdin);
                    rute[strcspn(rute, "\n")] = '\0'; // Menghapus newline dari input

                    // TODO: Cek apakah rute tersedia di file rute.txt

                    int harga = mobilList[mobilIndex].harga[0]; // Mengambil harga untuk rute pertama

                    char waktuPemakaian[MAX_WAKTU];
                    char waktuPengembalian[MAX_WAKTU];

                    printf("Masukkan waktu pemakaian (YYYY-MM-DD): ");
                    scanf("%s", waktuPemakaian);

                    printf("Masukkan waktu pengembalian (YYYY-MM-DD): ");
                    scanf("%s", waktuPengembalian);

                    // TODO: Lakukan validasi waktu pemakaian dan pengembalian

                    // Menampilkan ringkasan transaksi
                    printf("\nRingkasan Transaksi:\n");
                    printf("Jenis Mobil: %s\n", jenisMobil);
                    printf("Rute: %s\n", rute);
                    printf("Harga: %d\n", harga);
                    printf("Waktu Pemakaian: %s\n", waktuPemakaian);
                    printf("Waktu Pengembalian: %s\n", waktuPengembalian);

                    // Menyimpan data transaksi ke dalam array
                    transaksi = realloc(transaksi, (jumlahTransaksi + 1) * sizeof(Transaksi));
                    strcpy(transaksi[jumlahTransaksi].nama, nama);
                    strcpy(transaksi[jumlahTransaksi].jenisMobil, jenisMobil);
                    strcpy(transaksi[jumlahTransaksi].rute, rute);
                    transaksi[jumlahTransaksi].harga = harga;
                    strcpy(transaksi[jumlahTransaksi].waktuPemakaian, waktuPemakaian);
                    strcpy(transaksi[jumlahTransaksi].waktuPengembalian, waktuPengembalian);

                    jumlahTransaksi++;

                    printf("Peminjaman berhasil dicatat.\n");
                } else {
                    printf("Jenis mobil tidak tersedia.\n");
                }
                break;

            case 2: // Lihat Ketersediaan Mobil
                tampilkanJenisMobil(mobilList, mobilCount);
                break;

            case 3: // Cek Mobil Tersedia (per tanggal)
                // TODO: Implementasi pengecekan mobil tersedia per tanggal
                break;

            case 4: // Lihat Riwayat Transaksi
                printf("\nRiwayat Transaksi:\n");
                for (i = 0; i < jumlahTransaksi; i++) {
                    printf("| %s | %s | %s | %d | %s | %s |\n",
                            transaksi[i].nama, transaksi[i].jenisMobil, transaksi[i].rute,
                            transaksi[i].harga, transaksi[i].waktuPemakaian, transaksi[i].waktuPengembalian);
                }
                break;

            case 0: // Keluar
                // Menyimpan data transaksi ke dalam file
                catatTransaksi(transaksi, jumlahTransaksi);

                // Membebaskan memory yang dialokasikan
                free(mobilList);
                free(transaksi);

                printf("Terima kasih, sampai jumpa!\n");
                break;

            default:
                printf("Pilihan tidak valid. Silakan coba lagi.\n");
        }

    } while (pilihan != 0);

    return 0;
}
